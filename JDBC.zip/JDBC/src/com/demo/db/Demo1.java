package com.demo.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Demo1 {

	public static void main(String[] args) throws Exception {

		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "adp", "welcome1");

		if (con != null) {
			System.out.println("Connected...");
		}

		Statement stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery("select ID,FIRST_NAME,EMAIL,SALARY from Employees");
		while (rs.next()) {
			int id = rs.getInt("ID");
			String fname = rs.getString("FIRST_NAME");
			String email = rs.getString("EMAIL");
			double salary = rs.getDouble("SALARY");
			System.out.println(id + " " + fname + " " + email + " " + salary);
		}

	}

}
