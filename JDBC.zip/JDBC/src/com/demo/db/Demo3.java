package com.demo.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class Demo3 {

	public static void main(String[] args) throws Exception {

		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "adp", "welcome1");

		if (con != null) {
			System.out.println("Connected...");
		}

		PreparedStatement pst = con.prepareStatement(
				"insert into employees(ID,FIRST_NAME,LAST_NAME,EMAIL,"
				+ "PHONE_NUMBER,HIRE_DATE,JOB_ID,SALARY,"
				+ "COMMISSION,MANAGER_ID,DEPARTMENT_ID) values(?,?,?,?,?,?,?,?,?,?,?)");
		
		pst.setInt(1,301);
		pst.setString(2, "James");
		pst.setString(3, "Collins");
		pst.setString(4, "scott@nowhere.com");
		pst.setString(5,"123456");
		pst.setString(6,"28-07-2001");
		pst.setString(7,"SH_CLERK");
		pst.setDouble(8,6700);
		pst.setDouble(9, 0.1);
		pst.setInt(10,124);
		pst.setInt(11, 50);
		
		int rows= pst.executeUpdate();
		System.out.println("rows Inserted : "+rows);

	}

}
