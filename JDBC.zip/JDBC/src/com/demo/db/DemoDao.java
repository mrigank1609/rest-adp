package com.demo.db;

import java.text.SimpleDateFormat;
import java.util.Date;

public class DemoDao {

	public static void main(String[] args) throws Exception{
		EmpDao dao= new EmpDaoJdbcImpl();
		
		Employee e=dao.getById(203);
		
		System.out.println(e.getFirstName()+" "+e.getEmail()+" "+e.getDeptId()+" "+e.getHireDate());
		
		Employee e1= new Employee();
		
		e1.setId(223);
		e1.setFirstName("James");
		e1.setLastName("Cameron");
		e1.setEmail("aa@abc.com");
		e1.setJobId("SH_CLERK");
		
		SimpleDateFormat df= new SimpleDateFormat("dd-MMM-yyyy");
		
		Date date=df.parse("20-JAN-2001");
		
		e1.setHireDate(date);
		e1.setCommission(0.2);
		e1.setSalary(560);
		e1.setManagerId(142);
		e1.setDeptId(50);
		e1.setPhoneNumber("98989898");

		Employee e2=dao.save(e1);
	}

}
