package com.demo.db;

import java.util.List;

public interface EmpDao {
	public Employee save(Employee e);

	public Employee getById(int id);

	public Employee update(Employee e);

	public String delete(int id);

	public List<Employee> getAllEmployees();

}
