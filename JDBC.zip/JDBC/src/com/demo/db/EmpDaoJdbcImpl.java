package com.demo.db;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

public class EmpDaoJdbcImpl implements EmpDao {

	@Override
	public Employee save(Employee e) {
		Connection con = null;
		try {
			con = getConnection();
			PreparedStatement pst = con.prepareStatement(
					"insert into employees(ID,FIRST_NAME,LAST_NAME,EMAIL," + "PHONE_NUMBER,HIRE_DATE,JOB_ID,SALARY,"
							+ "COMMISSION,MANAGER_ID,DEPARTMENT_ID) values(?,?,?,?,?,?,?,?,?,?,?)");

			pst.setInt(1, e.getId());
			pst.setString(2, e.getFirstName());
			pst.setString(3, e.getLastName());
			pst.setString(4, e.getEmail());
			pst.setString(5, e.getPhoneNumber());
			pst.setDate(6, new Date(e.getHireDate().getTime()));
			pst.setString(7, e.getJobId());
			pst.setDouble(8, e.getSalary());
			pst.setDouble(9, e.getCommission());
			pst.setInt(10, e.getManagerId());
			pst.setInt(11, e.getDeptId());
			int rows = pst.executeUpdate();
		} catch (SQLException ex) {
			ex.printStackTrace();
		} catch (ClassNotFoundException e2) {
			e2.printStackTrace();
		}

		finally {
			try {
				con.close();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		}
		return e;
	}

	@Override
	public Employee getById(int id) {
		Employee e = null;
		Connection con = null;
		try {
			con = getConnection();
			PreparedStatement pst = con.prepareStatement("select * from employees where id=?");
			pst.setInt(1, id);
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				e = new Employee();
				e.setId(rs.getInt("ID"));
				e.setFirstName(rs.getString("FIRST_NAME"));
				e.setLastName(rs.getString("LAST_NAME"));
				e.setJobId(rs.getString("JOB_ID"));
				e.setSalary(rs.getDouble("SALARY"));
				e.setCommission(rs.getDouble("COMMISSION"));
				e.setManagerId(rs.getInt("MANAGER_ID"));
				e.setEmail(rs.getString("EMAIL"));
				e.setDeptId(rs.getInt("DEPARTMENT_ID"));
				e.setHireDate(rs.getDate("HIRE_DATE"));
				e.setPhoneNumber(rs.getString("PHONE_NUMBER"));
			}
		} catch (ClassNotFoundException ex) {
			ex.printStackTrace();
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			try {
				con.close();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		}
		return e;
	}

	@Override
	public Employee update(Employee e) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String delete(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Employee> getAllEmployees() {
		// TODO Auto-generated method stub
		return null;
	}

	// Get A Connection from here!!
	public Connection getConnection() throws ClassNotFoundException, SQLException {
		Connection con = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "adp", "welcome1");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			throw e;
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		}
		return con;
	}
}
